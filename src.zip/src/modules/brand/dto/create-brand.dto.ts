export class CreateBrandDto {}
